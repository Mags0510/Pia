Set-StrictMode -Version Latest
#funcion2
function main {


    param (
        [string]$Path
    )

    # Verificar si se proporcionó una ruta
    if ([string]::IsNullOrWhiteSpace($Path)) {
        Write-Error "No se ha proporcionado una ruta válida."
        return
    }

    # Mostrar la ruta proporcionada para verificación
    Write-Host "Ruta proporcionada: $Path"

    # Verificar si la ruta existe
    if (-Not (Test-Path -Path $Path)) {
        Write-Error "La ruta especificada no existe."
        return
    }

    # Buscar archivos ocultos
    $hiddenFiles = Get-ChildItem -Path $Path -Force | Where-Object { $_.Attributes -match "Hidden" }
    
    if ($hiddenFiles) {
        $hiddenFiles | ForEach-Object { Write-Output "Archivo oculto: $($_.FullName)" }
    } else {
        Write-Host "No se encontraron archivos ocultos en la ruta especificada."
    }
}

main