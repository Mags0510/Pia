﻿function virustotal{
    param(
    $key = 'b0005fdf0592d5c1dae7c72bb54211b4edce151271c5f09863a54149a3b34b03',
    $dic = @{},
    $ve2 = [System.Collections.ArrayList]@(Get-ChildItem -name)
    )

    process{foreach ($item in $ve2) {
    $body = @{
        resource = (Get-FileHash -Path ".\$item").hash
        apikey = $key
    }

    $result = Invoke-RestMethod -Method GET -Uri 'https://www.virustotal.com/vtapi/v2/file/report' -Body $body

    if ($result.response_code -eq 1) {
        if ($result.positives -eq 0) {
            $dic[$item] = 'no se encontro ninguna anomalia'
        } else {
            $dic[$item] = 'se encontraron ' + $result.positives + ' anomalias'
        }
    } else {
        $dic[$item] = 'no funciono, intenta hacerlo manualmente'
    }
}

$dic
}
}
virustotal