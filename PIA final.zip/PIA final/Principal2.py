import argparse
import subprocess
import importlib
import platform


modulos_disponibles = {
    "python": ["API_IPABUSE", "Complejo", "deteccion", "trafico"],
    "powershell": ["ListadoDeArchivosOcultos", "modulo2", "Modulo_UsoRecursos", "virus"],
    "bash": ["escaneo_puertos", "Monitoreo_Red"]
}

def mostrar_menu_principal():
    print("\nSelecciona el tipo de módulo que quieres ejecutar:")
    opciones = list(modulos_disponibles.keys())
    for i, tipo in enumerate(opciones, 1):
        print(f"{i}. {tipo.capitalize()}")
    
    while True:
        try:
            seleccion = int(input("Elige una opción (número): ")) - 1
            if 0 <= seleccion < len(opciones):
                return opciones[seleccion]
            else:
                print("Selección inválida. Por favor, elige un número dentro del rango.")
        except ValueError:
            print("Por favor, ingresa un número válido.")

def mostrar_menu_modulos(tipo):
    print(f"\nSelecciona el módulo de {tipo.capitalize()} que quieres ejecutar:")
    modulos = modulos_disponibles[tipo]
    for i, modulo in enumerate(modulos, 1):
        print(f"{i}. {modulo}")
    
    while True:
        try:
            seleccion = int(input("Elige una opción (número): ")) - 1
            if 0 <= seleccion < len(modulos):
                return modulos[seleccion]
            else:
                print("Selección inválida. Por favor, elige un número dentro del rango.")
        except ValueError:
            print("Por favor, ingresa un número válido.")

def preguntar_ayuda():
    print("\n¿Quieres ver la ayuda del módulo antes de ejecutarlo?")
    print("1. Sí")
    print("2. No")
    
    while True:
        try:
            seleccion = int(input("Elige una opción (número): "))
            if seleccion in [1, 2]:
                return seleccion == 1
            else:
                print("Selección inválida. Por favor, elige 1 o 2.")
        except ValueError:
            print("Por favor, ingresa un número válido.")

def ejecutar_modulo_python(modulo, parametros=None):
    try:
        mod = importlib.import_module(modulo)
        if hasattr(mod, 'main'):
            if parametros:
                mod.main(*parametros)
            else:
                mod.main()
        else:
            print(f"El módulo {modulo} no tiene una función main.")
    except ModuleNotFoundError:
        print(f"El módulo {modulo} no fue encontrado.")

def ejecutar_modulo_powershell(modulo, parametros=None):
    if platform.system() != "Windows":
        return "PowerShell solo está disponible en Windows."
    try:
        comando = f"powershell -ExecutionPolicy Bypass -Command \"Import-Module .\\{modulo}.psm1; {modulo} main\""
        if parametros:
            comando += ' ' + ' '.join(parametros)
        resultado = subprocess.run(comando, shell=True, capture_output=True, text=True, check=True)
        return resultado.stdout  # Retorna la salida estándar del comando
    except subprocess.CalledProcessError as e:
        return f"Error al ejecutar el módulo PowerShell {modulo}: {e.stderr}"  # Muestra el error detallado

def ejecutar_modulo_bash(modulo, parametros=None):
    if platform.system() == "Windows":
        print("Bash no está disponible en Windows.")
        return
    try:
        comando = f"bash {modulo}.sh"
        if parametros:
            comando += ' ' + ' '.join(parametros)
        subprocess.run(comando, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error al ejecutar el módulo Bash {modulo}: {e}")

def main():
    parser = argparse.ArgumentParser(description="Programa principal para ejecutar varios módulos.")
    parser.add_argument('--params', nargs=argparse.REMAINDER, help="Parámetros adicionales para el módulo")

    args = parser.parse_args()

    tipo = mostrar_menu_principal()

    modulo = mostrar_menu_modulos(tipo)

    ver_ayuda = preguntar_ayuda()

    if ver_ayuda:
        if tipo == 'python':
            ejecutar_modulo_python(modulo, parametros=['--help'])
        elif tipo == 'powershell':
            ejecutar_modulo_powershell(modulo, parametros=['-help'])
        elif tipo == 'bash':
            ejecutar_modulo_bash(modulo, parametros=['--help'])
    else:
        if tipo == 'python':
            ejecutar_modulo_python(modulo, parametros=args.params)
        elif tipo == 'powershell':
            ejecutar_modulo_powershell(modulo, parametros=args.params)
        elif tipo == 'bash':
            ejecutar_modulo_bash(modulo, parametros=args.params)
        else:
            print("Por favor, especifica un tipo de módulo válido.")

if __name__ == '__main__':
    main()
